#!/bin/bash

OUTFILE="lab3_eceubuntu1.csv"
echo "B,P,C,X,N,Time" > "$OUTFILE"

NUM_RUNS=5
IMG_NUM=1

configs=(
"5 1 1 0"
"5 1 5 0"
"5 5 1 0"
"5 5 5 0"
"10 1 1 0"
"10 1 5 0"
"10 1 10 0"
"10 5 1 0"
"10 5 5 0"
"10 5 10 0"
"10 10 1 0"
"10 10 5 0"
"10 10 10 0"
"5 1 1 200"
"5 1 5 200"
"5 5 1 200"
"5 5 5 200"
"10 1 1 200"
"10 1 5 200"
"10 1 10 200"
"10 5 1 200"
"10 5 5 200"
"10 5 10 200"
"10 10 1 200"
"10 10 5 200"
"10 10 10 200"
"5 1 1 400"
"5 1 5 400"
"5 5 1 400"
"5 5 5 400"
"10 1 1 400"
"10 1 5 400"
"10 1 10 400"
"10 5 1 400"
"10 5 5 400"
"10 5 10 400"
"10 10 1 400"
"10 10 5 400"
"10 10 10 400"
)

for cfg in "${configs[@]}"; do
    B=$(echo $cfg | awk '{print $1}')
    P=$(echo $cfg | awk '{print $2}')
    C=$(echo $cfg | awk '{print $3}')
    X=$(echo $cfg | awk '{print $4}')
    
    total_time=0

    for ((i = 1; i <= NUM_RUNS; i++)); do
        make clean > /dev/null
        make > /dev/null

        output=$(./paster2 $B $P $C $X $IMG_NUM | grep "paster2 execution time")
        time=$(echo "$output" | awk '{print $4}')

        # Safety check to avoid adding empty values
        if [[ -n "$time" ]]; then
            total_time=$(echo "$total_time + $time" | bc)
            echo "Run $i: B=$B P=$P C=$C X=$X -> time=$time"
        else
            echo "Run $i: B=$B P=$P C=$C X=$X -> time=ERROR"
        fi
    done

    avg=$(echo "scale=6; $total_time / $NUM_RUNS" | bc)
    echo "$B,$P,$C,$X,$IMG_NUM,$avg" >> "$OUTFILE"
done

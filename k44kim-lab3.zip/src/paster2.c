#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <curl/curl.h>
#include <pthread.h>
#include <getopt.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include "lab_png.h" 

#define BUF_SIZE 1048576  //1MB inital buffer
#define NUM_FRAGS 50
#define ECE252_HEADER "X-Ece252-Fragment: " 

#define SHM_KEY 0x1234

#define SEM_KEY 0x5678

extern int concatenate_png(int argc, char *argv[]);

//used for shared memory
typedef struct {
    int seqnum; //sequence number for fragments
    size_t size; //size of valid data
    char data[BUF_SIZE]; //image data
} img_frags;

//Shared Mem - Using Circular Queue for Producer/Consumer
typedef struct {
    int head; //read the index
    int tail; //write the index
    int slots; //space in buffer
    int saved_count;
    int request; //tracking total requests made
    int completion_flag; //flag to signal completion 
    int downloaded[NUM_FRAGS]; //tracking the downloaded segments
    int saved[NUM_FRAGS];
    img_frags buffer[]; //size based on user input
} shared_buffer;

typedef unsigned char U8;

//from lab 2
//used for curl callbacks
typedef struct recv_buf {
    char *buf;       /* memory to hold a copy of received data */
    size_t size;     /* size of valid data in buf in bytes*/
    size_t max_size; /* max capacity of buf in bytes*/
    int seq;         /* >=0 sequence number extracted from http header */
                     /* <0 indicates an invalid seq number */
} RECV_BUF;

//from lab 2
size_t write_cb_curl(char *p_recv, size_t size, size_t nmemb, void *p_userdata) {
    size_t realsize = size * nmemb; //calculating the total number of bytes received in this callback
    RECV_BUF *p = (RECV_BUF *)p_userdata;
 
    //checking if there is enough space left in the buffer to store new data
    if (p->size + realsize > p->max_size) {
        return 0;
    }

    memcpy(p->buf + p->size, p_recv, realsize); /*copy data from libcurl*/
    p->size += realsize; //update the total number of valid bytes in buffer

    return realsize;
}

//from lab 2
size_t header_cb_curl(char *p_recv, size_t size, size_t nmemb, void *userdata) {
    size_t realsize = size * nmemb;
    RECV_BUF *p = userdata;
    
    if ((size_t)realsize > strlen(ECE252_HEADER) && strncmp(p_recv, ECE252_HEADER, strlen(ECE252_HEADER)) == 0) {
        /* extract img sequence number */
	    p->seq = atoi(p_recv + strlen(ECE252_HEADER));
    }
    
    return realsize;
}

//SETTING UP SHARED MEMORY
shared_buffer *shared_mem_init(int buf_slots, int *shared_mem_id) {
    //buf_slots - how many image fragments to hold in circular queue
    //shared mem id - pointer to store the shared memory id

    int shm_size = sizeof(shared_buffer) + (buf_slots * sizeof(img_frags));

    //create a shared memory
    int shmid = shmget(IPC_PRIVATE, shm_size, IPC_CREAT|0666);

    if ( shmid == -1 ){
        perror("shmget");
        abort(); //immediately terminates
    }

    //attach the shared memory to address space of the process
    shared_buffer *buf = shmat(shmid, NULL, 0);

    if (buf == (void *) -1 ) {
        perror("shmat");
        abort();
    }

    memset(buf, 0, shm_size);

    //initializing head, tail, and buffer slots for queue
    buf->head=0;
    buf->tail=0;
    buf->slots= buf_slots;
    buf->request = 0;
    buf->completion_flag = 0;

    memset(buf->downloaded, 0, sizeof(buf->downloaded));
    memset(buf->saved, 0, sizeof(buf->saved));

    *shared_mem_id = shmid;
    return buf; //returning a pointer
}

//SETTING UP SEMAPHORES
int semaphore_init(int slots) {
    int semid = semget(IPC_PRIVATE, 3, IPC_CREAT|0666);

    if (semid == -1) {
        perror("semget");
        abort();
    }

    //semaphore 0 = mutex, only one process can access the buffer
    if (semctl(semid, 0, SETVAL, 1) == -1) {
        perror("mutex");
        abort();
    }

    //semaphore 1 = empty slots, how many slots are empty
    if (semctl(semid, 1, SETVAL, slots) == -1) {
        perror("empty");
        abort();
    }

    //semphore 2 = full slots, how many slots are filled
    if (semctl(semid, 2, SETVAL, 0) == -1) {
        perror("full");
        abort();
    }

    return semid;
}

//Sem wait on producers/consumers
void sem_wait_pc(int semid, int sem_num) {
    struct sembuf wait_op;
    wait_op.sem_num = sem_num; //index in semaphore 
    wait_op.sem_op = -1; //waiting (decrement)
    wait_op.sem_flg = 0; //block if not available

    if(semop(semid, &wait_op, 1) == -1) {
        perror("sem wait");
        abort();
    }
}

void sem_signal_pc(int semid, int sem_num) {
    struct sembuf signal_op;
    signal_op.sem_num = sem_num; //index in semaphore 
    signal_op.sem_op = 1; //signal (increment)
    signal_op.sem_flg = 0; //block if not available

    if(semop(semid, &signal_op, 1) == -1) {
        perror("sem signal");
        abort();
    }
}

int total_downloaded = 0;        // count of how many unique parts downloaded

//producer forking
void producer(int semid, shared_buffer *shm, int img_num) {

    const int max = 10; //maximum number of retry attempts per fragment

    while (1) {
        sem_wait_pc(semid, 0); // lock mutex

        int done = (shm->saved_count >= NUM_FRAGS);
        sem_signal_pc(semid, 0);
        if (done) {
            break;
        }

        //printf("[Producer %d] Got mutex, saved_count=%d\n", getpid(), shm->saved_count);

        // if (shm->saved_count >= NUM_FRAGS) {
        //     //printf("[Producer %d] All fragments saved, exiting\n", getpid());
        //     sem_signal_pc(semid, 0); // unlock before exiting
        //     break;
        // }

        //find a fragment that hasn't been downloaded yet
        int part = -1;
        for (int i = 0; i < NUM_FRAGS; i++) {
            if (shm->downloaded[i] == 0 && shm->saved[i]==0) {
                shm->downloaded[i] = -1; // mark as in progress
                part = i;
                break;
            }
        }

        sem_signal_pc(semid, 0);

        if (part == -1) {
            //nothing left to do, just exit
            break;
        }

        sem_wait_pc(semid, 1); 

        //retry loop for failed requests
        int success = 0;

        for (int retry=0; retry < max; retry++) {
            sem_wait_pc(semid, 0);
            int already_saved = shm->saved[part];
            sem_signal_pc(semid, 0);
            if (already_saved) {
                break;
            }

            //from lab 2, setting up recv buf
            RECV_BUF recv_buf;
            recv_buf.buf = malloc(BUF_SIZE);
            recv_buf.size = 0; //this is the current size of valid data (starting at 0)
            recv_buf.max_size = BUF_SIZE; //max capacity
            recv_buf.seq=-1;

            int server_num = (rand() % 3) + 1; //randomize the server number
            //printf("Thread %lu using server %d for request\n", pthread_self(), server_num);
            char url_server[128];
            snprintf(url_server, sizeof(url_server),"http://ece252-%d.uwaterloo.ca:2530/image?img=%d&part=%d", server_num, img_num, part);

            //printf("[Producer %d] Requesting part %d from server %d\n", getpid(), part, server_num);

            //from lab 2 - setting up libcurl
            CURL *curl_handle = curl_easy_init();

            if (!curl_handle) {
                //printf("[Producer %d] Failed to init curl\n", getpid());
                free(recv_buf.buf);
                continue;
            }

            curl_easy_setopt(curl_handle, CURLOPT_URL, url_server);
            curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_cb_curl); 
            curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)&recv_buf);
            curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");
            curl_easy_setopt(curl_handle, CURLOPT_HEADERFUNCTION, header_cb_curl); 
            curl_easy_setopt(curl_handle, CURLOPT_HEADERDATA, (void *)&recv_buf);

            curl_easy_setopt(curl_handle, CURLOPT_TIMEOUT_MS, 2000);

            //printf("[Producer %d] About to perform curl request for part %d\n", getpid(), part);
            CURLcode res = curl_easy_perform(curl_handle);
            curl_easy_cleanup(curl_handle);

            //printf("[Producer %d] Received header: seq = %d\n", getpid(), recv_buf.seq);
            int png_result = is_png((U8 *)recv_buf.buf, 8);

            if (res == CURLE_OK && recv_buf.seq == part && png_result == 1) {
                // failed or invalid, make fragment available again
                sem_wait_pc(semid, 0);

                if (shm->saved[part] == 0 && shm->saved_count < NUM_FRAGS) {
                    int tail = shm->tail;
                    shm->buffer[tail].seqnum = part;
                    shm->buffer[tail].size = recv_buf.size;
                    memcpy(shm->buffer[tail].data, recv_buf.buf, recv_buf.size);
                    shm->tail = (tail+1)%shm->slots; //updating tail to the next available slot

                    shm->downloaded[part] = 1;
                    shm->request++;
                    success=1;
                } else {
                    shm->downloaded[part] = 1;
                }
                
                sem_signal_pc(semid, 0);

                if (success) {
                    sem_signal_pc(semid, 2);
                } else {
                    sem_signal_pc(semid, 1);
                }
                
                free(recv_buf.buf);
                break;
            }

            free(recv_buf.buf);

        }
        if (!success) {
            sem_wait_pc(semid, 0);
            if (shm->saved[part] == 0) {
                shm->downloaded[part] = 0;
            }
            sem_signal_pc(semid, 0);
            sem_signal_pc(semid, 1); // Release empty slot
        }
    }
}

//consumer forking
void consumer(int semid, shared_buffer *shm, int sleep, int img_num) {

    //keep running until all fragments have been received
    while (1) {
        //printf("[Consumer %d] Started.\n", getpid());

        if (shm->completion_flag && shm->saved_count >= NUM_FRAGS) {
        break;
        }

        sem_wait_pc(semid, 2);
        //printf("[DEBUG] Consumer %d got full slot. head=%d\n", getpid(), shm->head);


        // Double check immediately after wake-up
        if (shm->completion_flag && shm->saved_count >= NUM_FRAGS) {
            sem_signal_pc(semid, 2); // release so other consumers don’t hang
            break;
        }
        sem_wait_pc(semid, 0); // mutex

        //printf("[Consumer %d] Got data, saved_count=%d\n", getpid(), shm->saved_count);

        //check completion flag first
        if (shm->saved_count >= NUM_FRAGS) {
            sem_signal_pc(semid, 0);
            sem_signal_pc(semid, 2);
            break;
        }

        int head = shm->head;
        int seq = shm->buffer[head].seqnum;
        //printf("[Consumer %d] Processing seq %d from head %d\n", getpid(), seq, head);

        //checking if fragment has already been saved
        if (shm->saved[seq]) {
            //printf("[Consumer %d] Seq %d already saved, skipping\n", getpid(), seq);
            shm->head = (head + 1) % shm->slots;
            sem_signal_pc(semid, 0); // unlock mutex
            sem_signal_pc(semid, 1); // increment empty count
            continue;
        }

        char filename[32];
        snprintf(filename, sizeof(filename), "image%d.png", seq);

        FILE *fp = fopen(filename, "wb");
        if (fp) {
            fwrite(shm->buffer[head].data, 1, shm->buffer[head].size, fp);
            fclose(fp);

            shm->saved[seq] = 1;
            shm->saved_count++;
            //printf("[Consumer %d] Saved image%d.png (Total saved: %d)\n", getpid(), seq, shm->saved_count);

        } else {
            perror("fopen");
        }

        // Update head and release semaphores
        shm->head = (head + 1) % shm->slots;

        //check if we just completed everything
        int finish = (shm->saved_count >= NUM_FRAGS);
        
        sem_signal_pc(semid, 0); //unlock mutex
        sem_signal_pc(semid, 1); // increment empty count

        if (finish) {
            break;  // Just exit normally
        }

        if (sleep > 0) {
            usleep(sleep * 1000);
        }
    }
}

int main(int argc, char *argv[]) {

    if (argc != 6) {
        return -1;
    }

    signal(SIGTERM, SIG_DFL);
    signal(SIGPIPE, SIG_IGN);

    srand(time(NULL));
    
    //arguments
    int slots = atoi(argv[1]); //B - buffer size
    int producers = atoi(argv[2]); //P - number of producers
    int consumers = atoi(argv[3]); //C - number of consumers
    int sleep = atoi(argv[4]); //X - number of milliseconds
    int img_num = atoi(argv[5]); //N - image number you want to get from server

    //printf("Starting with: slots=%d, producers=%d, consumers=%d, sleep=%d, img=%d\n", slots, producers, consumers, sleep, img_num);

    struct timeval start_time, end_time;
    gettimeofday(&start_time, NULL); // Start timer

    //shared memory initialization
    int shmid;
    shared_buffer *shm = shared_mem_init(slots, &shmid);

    //semaphore initializtion
    int semid = semaphore_init(slots);

    pid_t producer_pids[producers];
    pid_t consumer_pids[consumers];

    //fork producers
    for (int i=0; i<producers; i++) {
        pid_t pid = fork();
        if (pid==0) {
            producer(semid, shm, img_num);
            exit(0); 
        }
        producer_pids[i] = pid;
    }

    //fork consumers
    for (int i=0; i<consumers; i++) {
        pid_t pid = fork();
        if (pid==0) {
            consumer(semid, shm, sleep, img_num);
            exit(0); 
        }
        consumer_pids[i] = pid;
    }

    // Wait until all fragments are saved
    while (1) {
        sem_wait_pc(semid, 0); // lock
        int done = (shm->saved_count >= NUM_FRAGS);
        sem_signal_pc(semid, 0); // unlock
        if (done) break;
    }

    // Signal consumers to exit
    shm->completion_flag = 1;

    for (int i = 0; i < consumers; i++) {
        sem_signal_pc(semid, 2); // wake up blocked consumers
    }

    // Now safely wait for consumers
    for (int i = 0; i < consumers; i++) {
        waitpid(consumer_pids[i], NULL, 0);
    }

    //printf("[DEBUG] All consumers have exited. Setting completion_flag.\n");


    //printf("[DEBUG] completion_flag set. Signaled sem[2] to wake remaining consumers.\n");

    // kill producers after all fragments saved
    for (int i = 0; i < producers; i++) {
        kill(producer_pids[i], SIGTERM);  // or SIGKILL if needed
        wait(NULL);
    }

    //printf("FINISHED P\n");

    /*DEBUG: Check which files actually exist on disk
    printf("=== FILE EXISTENCE CHECK ===\n");
    int files_exist = 0;
    for (int i = 0; i < NUM_FRAGS; i++) {
        char filename[32];
        snprintf(filename, sizeof(filename), "image%d.png", i);
        FILE *test = fopen(filename, "rb");
        if (test) {
            fclose(test);
            files_exist++;
            printf("✓ image%d.png exists\n", i);
        } else {
            printf("✗ image%d.png MISSING\n", i);
        }
    }
    printf("Total files on disk: %d/%d\n", files_exist, NUM_FRAGS);

    if (files_exist != NUM_FRAGS) {
        printf("ERROR: Not all fragments were saved! Cannot concatenate.\n");
        return -1;
    }
    */

    char *args[NUM_FRAGS];
    char filenames[NUM_FRAGS][32];

    for (int i = 0; i < NUM_FRAGS; i++) {
        snprintf(filenames[i], sizeof(filenames[i]), "image%d.png", i);
        args[i] = filenames[i];  //array of images
    }

    //printf("Concatenation starting...\n");
    concatenate_png(NUM_FRAGS, args); //calling catpng.c

    gettimeofday(&end_time, NULL); // Stop timer

    double elapsed = (end_time.tv_sec - start_time.tv_sec) +
                    (end_time.tv_usec - start_time.tv_usec) / 1000000.0;

    printf("paster2 execution time: %.6f seconds\n", elapsed);

    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);

}
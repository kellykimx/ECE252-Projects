#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <curl/curl.h>
#include <pthread.h>
#include <getopt.h>
#include "lab_png.h" 

extern int concatenate_png(int argc, char *argv[]);

//using main_write_header_cb.c file for reference (Starter code)
//also referencing from pthreads/main.c

#define BUF_SIZE 1048576  //1MB inital buffer
#define BUF_INC  524288   //0.5MB increment
#define NUM_FRAGS 50
#define NUM_THREADS 10
#define ECE252_HEADER "X-Ece252-Fragment: " 
#define IMG_URL "http://ece252-1.uwaterloo.ca:2520/image?img=1"

typedef struct recv_buf {
    char *buf;       /* memory to hold a copy of received data */
    size_t size;     /* size of valid data in buf in bytes*/
    size_t max_size; /* max capacity of buf in bytes*/
    int seq;         /* >=0 sequence number extracted from http header */
                     /* <0 indicates an invalid seq number */
} RECV_BUF;

typedef struct {
    const char *url;
} thread_args;

int received[NUM_FRAGS] = {0};
int total_received = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

#define max(a, b) ((a)>(b) ? (a):(b)) //will be used or buffer later on

//callback to write data
//stores received binary image data into a dynamically allocated buffer
//*p_recv: pointer to received data, size: size of each unit, nmemb: number of units, *p_userdata: user-defined memory location
size_t write_cb_curl(char *p_recv, size_t size, size_t nmemb, void *p_userdata) {
    size_t realsize = size * nmemb; //calculating the total number of bytes received in this callback
    RECV_BUF *p = (RECV_BUF *)p_userdata;
 
    //checking if there is enough space left in the buffer to store new data
    if (p->size + realsize + 1 > p->max_size) {/* hope this rarely happens */ 
        /* received data is not 0 terminated, add one byte for terminating 0 */
        size_t new_size = p->max_size + max(BUF_INC, realsize + 1); //determining how much to grow the buffer
        char *q = realloc(p->buf, new_size); //resize the buffer
        if (q == NULL) { //if it fails
            perror("realloc"); /* out of memory */
            return -1;
        }
        //update buffer pointer and size 
        p->buf = q;
        p->max_size = new_size;
    }

    memcpy(p->buf + p->size, p_recv, realsize); /*copy data from libcurl*/
    p->size += realsize; //update the total number of valid bytes in buffer
    p->buf[p->size] = 0; //null terminate for safety

    return realsize;
}

 //if the header matches, it parses the number and stores it in recv_buf.seq
size_t header_cb_curl(char *p_recv, size_t size, size_t nmemb, void *userdata) {
    int realsize = size * nmemb;
    RECV_BUF *p = userdata;
    
    if ((size_t)realsize > strlen(ECE252_HEADER) && strncmp(p_recv, ECE252_HEADER, strlen(ECE252_HEADER)) == 0) {
        /* extract img sequence number */
	    p->seq = atoi(p_recv + strlen(ECE252_HEADER));
    }
    
    return realsize;
}

void *thread_seg (void *arg) {
    thread_args *argument = (thread_args *)arg;
    int img_num = atoi(argument->url);  //extract image number from url string

    while (1) {
        pthread_mutex_lock(&lock);

        if(total_received >= NUM_FRAGS) {
            pthread_mutex_unlock(&lock);
            break;
        }
        pthread_mutex_unlock(&lock);

        int server_num = (rand() % 3) + 1; //randomize the server number
        //printf("Thread %lu using server %d for request\n", pthread_self(), server_num);

        char url_server[128];
        snprintf(url_server, sizeof(url_server), "http://ece252-%d.uwaterloo.ca:2520/image?img=%d", server_num, img_num);


        CURL *curl_handle = curl_easy_init();

        if (!curl_handle) {
            continue;
        }

        RECV_BUF recv_buf;
        recv_buf.buf = malloc(BUF_SIZE);
        recv_buf.size = 0; //this is the current size of valid data (starting at 0)
        recv_buf.max_size = BUF_SIZE; //max capacity
        recv_buf.seq=-1;

        //specify URL to get
        curl_easy_setopt(curl_handle, CURLOPT_URL, url_server);
        //register write call back function to process received data
        curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_cb_curl); 
        // user defined data structure passed to the call back function
        curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)&recv_buf);
        // some servers requires a user-agent field
        curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "libcurl-agent/1.0");
        // register header call back function to process received header data
        curl_easy_setopt(curl_handle, CURLOPT_HEADERFUNCTION, header_cb_curl); 
        // user defined data structure passed to the call back function
        curl_easy_setopt(curl_handle, CURLOPT_HEADERDATA, (void *)&recv_buf);

        //disables connection reuse and forces each request to hit potentially different servers
        curl_easy_setopt(curl_handle, CURLOPT_FRESH_CONNECT, 1L);
        curl_easy_setopt(curl_handle, CURLOPT_FORBID_REUSE, 1L);

        // get it! fetch the URL
        CURLcode res = curl_easy_perform(curl_handle);

        /* FOR DEBUGGING
        printf("[DEBUG] res=%d, seq=%d, size=%zu, is_png=%d\n",
        res, recv_buf.seq, recv_buf.size,
        is_png((U8 *)recv_buf.buf, 8));

        printf("First 8 bytes of fragment %d: ", recv_buf.seq);
        for (int i = 0; i < 8; i++) {
            printf("%02X ", (unsigned char)recv_buf.buf[i]);
        }
        printf("\n");
        */


        if((res == CURLE_OK) && 
            (recv_buf.seq >= 0) &&
            (recv_buf.seq < NUM_FRAGS) && 
            (recv_buf.size >= 8) && 
            (is_png((U8 *)recv_buf.buf, 8)==1))  {

                pthread_mutex_lock(&lock);

                if(!received[recv_buf.seq]) {
                    received[recv_buf.seq] = 1;
                    total_received++;

                    /*just to check if we are getting all the sequences
                    printf("Thread got seq: %d\n", recv_buf.seq);
                    
                    if (total_received % 5 == 0) {
                        printf("Progress: %d/%d fragments received\n", total_received, NUM_FRAGS);
                    }

                    //just to check if it is receiving
                    if (total_received == NUM_FRAGS) {
                        printf("All 50 fragments received!\n");
                    } */

                    pthread_mutex_unlock(&lock);

                    char filename[32];

                    snprintf(filename, sizeof(filename), "image%d.png", recv_buf.seq);

                    FILE *fp = fopen(filename, "wb");

                    if (fp) {
                        fwrite(recv_buf.buf, 1, recv_buf.size, fp);
                        fclose(fp);
                    }
                    //for checking if we are getting sequences
                    //printf("Saved fragment %d\n", recv_buf.seq);
                } else {
                    pthread_mutex_unlock(&lock);
                }
        }

        free(recv_buf.buf);
        curl_easy_cleanup(curl_handle);
    }
    return NULL;
}

int thread_count = 0;

int main(int argc, char *argv[]) {
    int opt; //t, n

    // -t is number of threads to create
    // -n is determining which image to request from server

    int num_threads = 1; //this is just the default value if -t is not provided
    int img_num = 1; //default image number

    //parse command-line options

    while ((opt = getopt(argc, argv, "t:n:")) != -1) {
        switch (opt) {
            case 't':
                num_threads = atoi(optarg); //atoi --> converting string to integer; ASCII to integer
                break;
            case 'n':
                img_num = atoi(optarg);
                if (img_num < 1 || img_num > 3) {
                    //fprintf(stderr, "Error: -n value must be 1, 2, or 3. \n");
                    return 1;
                }
                break;
            default:
                //fprintf(stderr, "Usage: %s [-t num_threads] [-n img_number]\n", argv[0]);
                return 1;
        }
    }

    curl_global_init(CURL_GLOBAL_DEFAULT);

    pthread_t tids[num_threads];
    thread_args argument = { .url = NULL };

    char img_num_str[8];
    snprintf(img_num_str, sizeof(img_num_str), "%d", img_num);
    argument.url = img_num_str;

    for (int i=0; i<num_threads; i++) {
        pthread_create(&tids[i], NULL, thread_seg, &argument); //running threads
        thread_count++;
    }

    for (int i=0; i<num_threads; i++) { //downloading the fragments
        pthread_join(tids[i], NULL);
    }

    char *args[NUM_FRAGS];
    char filenames[NUM_FRAGS][32];

    for (int i = 0; i < NUM_FRAGS; i++) {
        snprintf(filenames[i], sizeof(filenames[i]), "image%d.png", i);
        args[i] = filenames[i];  //array of images
    }

    //printf("Concatenation starting...\n");
    concatenate_png(NUM_FRAGS, args); //calling catpng.c

    curl_global_cleanup();
    return 0;
}

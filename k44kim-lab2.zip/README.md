ECE252 Lab2 starter files:
* `cURL` demonstrate using curl to download one random image segement of picture 1 from a lab server.
*  `fn_ptr` demonstrate C function pointer.
* `getopt` demonstrate how to use `getopt` to parse command line input options.
* `pthread` demonstrate how to create two threads.
* `times` demonstrate various timing API usage. For reference only, not required to do timing analysis in lab2.
* `img1.md5` The concatenated img1 md5 checksum. Use `md5sum <filename>` to compute the checksum.
* img/ contains image1 from on the server

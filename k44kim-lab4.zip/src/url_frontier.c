#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "url_frontier.h"

typedef struct url_node {
    char *url;
    struct url_node *next; //pointing to the next item in the list
} url_node_t;

//head and tail of the queue
static url_node_t *head = NULL; //front
static url_node_t *tail = NULL; //end


static pthread_mutex_t frontier_mutex; //lock that protexts the URL frontier 
                                       //this is needed to make sure that memory does not get corrupted, this can happen due to multiple threads accessing at the same time
static pthread_cond_t frontier_not_empty; //condition variable to put threads to sleep when it is empty, wake them up when new url gets added
                                          //this is so we dont waste cpu by for example trying to pop something out of the list when the list is empty


extern volatile int done;

void frontier_initialization() {
    //currently nothing in the list, just initializing 
    head = NULL;
    tail = NULL; 
    pthread_mutex_init(&frontier_mutex, NULL);
    pthread_cond_init(&frontier_not_empty, NULL);
}

void frontier_destroy() {
    pthread_mutex_lock(&frontier_mutex); //lock it so nothing disturbs the list while destroying

    url_node_t *current = head; //place the current pointer to the front of the list, using this to go through the list
    
    while (current != NULL) { //until we have visited every node in the list
        url_node_t *next = current->next;
        free(current->url); //free the item one by one
        free(current);
        current = next;
    }

    //after the list empties out, set everything back to NULL
    head=NULL;
    tail=NULL;

    pthread_mutex_unlock(&frontier_mutex); //done destroying so unlock it
    pthread_mutex_destroy(&frontier_mutex); //destroy mutex
    pthread_cond_destroy(&frontier_not_empty); //destroy the condition variable
}

void frontier_push(const char *url){
    url_node_t *new = malloc(sizeof(url_node_t)); //variable for new url that gets added onto the list
    new->url = strdup(url); //makes a copy of input string and stores it into new
    new->next = NULL; //since the new url gets added to the end of the list, make sure to set the next item as NULL so it indicates it is the last item

    pthread_mutex_lock(&frontier_mutex); //lock to update the list

    if (tail==NULL) { //if the queue is empty
        head = new;
        tail = new;
    } else {
        tail->next=new; //add the new url after 'tail'
        tail=new; //set new tail as new url
    }

    //printf("[Frontier] Pushed: %s\n", url);


    pthread_cond_signal(&frontier_not_empty); //notifying the thread
    pthread_mutex_unlock(&frontier_mutex); 
}

char *frontier_pop() {
    pthread_mutex_lock(&frontier_mutex); //lock to modify

    while (head == NULL) {
        if (done) {
            pthread_mutex_unlock(&frontier_mutex);
            return NULL;
        }
        pthread_cond_wait(&frontier_not_empty, &frontier_mutex);
    }

    url_node_t *poppop = head; //this is a temporary variable to hold so we can return the content later
    head = head->next; //set the new head as the next item

    if (head == NULL) { //if there was only one item on the list
        tail = NULL;
    }

    pthread_mutex_unlock(&frontier_mutex);

    char *url = poppop->url;
    //printf("[Frontier] Popped: %s\n", url);
    free(poppop); //free the url 
    return url;
}

int frontier_empty() {
    pthread_mutex_lock(&frontier_mutex); //lock because other threads might be pushing and poping to/from the list

    int empty; 
    if (head == NULL) {
        empty = 1; //true
    } else {
        empty = 0; //false
    }

    pthread_mutex_unlock(&frontier_mutex);

    return empty;
}

void frontier_wake_all() {
    pthread_mutex_lock(&frontier_mutex);
    pthread_cond_broadcast(&frontier_not_empty);
    pthread_mutex_unlock(&frontier_mutex);
}

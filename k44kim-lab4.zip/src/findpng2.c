#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <curl/curl.h>
#include <libxml/HTMLparser.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/uri.h>
#include <getopt.h>
#include <pthread.h>
#include "url_frontier.h"
#include "visited.h"
#include "lab_png.h" 

#define MAX_PNGS 50
#define NUM_THREADS 1
#define BUF_SIZE 1048576  //1MB inital buffer

#define ECE252_HEADER "X-Ece252-Fragment: "
#define SEED_URL "http://ece252-1.uwaterloo.ca/lab4/"

extern int concatenate_png(int argc, char *argv[]);

//global variables to use
int num_threads = NUM_THREADS; //how many threads the user wants
int max_pngs = MAX_PNGS; //max number of pngs to collect
int frag_num = -1;  // default to invalid
char *log_file = NULL; //visited url list
char *seed_url = NULL; //starting point

char *png_urls[MAX_PNGS]; //storing the png urls
int png_count = 0; //tracking how many pngs we have found
pthread_mutex_t png_mutex = PTHREAD_MUTEX_INITIALIZER;

volatile int done = 0;  //signals all threads to stop

typedef struct recv_buf {
    char *buf;       /* memory to hold a copy of received data */
    size_t size;     /* size of valid data in buf in bytes*/
    size_t max_size; /* max capacity of buf in bytes*/
    int seq;         /* >=0 sequence number extracted from http header */
                     /* <0 indicates an invalid seq number */
} RECV_BUF;

//from past labs
size_t write_cb_curl(char *p_recv, size_t size, size_t nmemb, void *p_userdata) {
    size_t realsize = size * nmemb; //calculating the total number of bytes received in this callback
    RECV_BUF *p = (RECV_BUF *)p_userdata;
 
    //checking if there is enough space left in the buffer to store new data
    if (p->size + realsize > p->max_size) {
        return 0;
    }

    memcpy(p->buf + p->size, p_recv, realsize); /*copy data from libcurl*/
    p->size += realsize; //update the total number of valid bytes in buffer

    return realsize;
}

size_t header_cb_curl(char *p_recv, size_t size, size_t nmemb, void *userdata) {
    size_t realsize = size * nmemb;
    RECV_BUF *p = userdata;
    
    if ((size_t)realsize > strlen(ECE252_HEADER) && strncmp(p_recv, ECE252_HEADER, strlen(ECE252_HEADER)) == 0) {
        /* extract img sequence number */
	    p->seq = atoi(p_recv + strlen(ECE252_HEADER));
    }
    
    return realsize;
}

int pnglist (const char *url) { //this is keeping track of the png urls that has been found
    pthread_mutex_lock(&png_mutex);

    //printf("[pnglist] Logging PNG #%d: %s\n", png_count, url);

    //checking if max png has already been reached
    if (png_count >= max_pngs) {
        pthread_mutex_unlock(&png_mutex);
        done=1;
        return 0;
    }

    //checking for duplicates
    for (int i=0; i<png_count; i++) {
        if (strcmp(png_urls[i], url)==0) {
            pthread_mutex_unlock(&png_mutex);
            return 0;
        }
    }

    //if max has not been reached & no duplicates, add to the list
    //printf("Found PNG: %s\n", url);
    png_urls[png_count]=strdup(url);
    png_count++;

    if (png_count >= max_pngs) {
        done = 1;
        frontier_wake_all();
    }

    pthread_mutex_unlock(&png_mutex);
    return 1; // Successfully added
}

//referencing from the starter code
int process_html(const char *buf, int size, const char *url) {

    //printf("[DEBUG] Entered process_html()\n");


    int opts = HTML_PARSE_NOBLANKS | HTML_PARSE_NOERROR | \
               HTML_PARSE_NOWARNING | HTML_PARSE_NONET;
    htmlDocPtr doc = htmlReadMemory(buf, size, url, NULL, opts);

    if ( doc == NULL ) {
        //fprintf(stderr, "Document not parsed successfully.\n");
        return 1;
    }

    xmlXPathContextPtr context = xmlXPathNewContext(doc);
    if (context == NULL) {
        //printf("Error in xmlXPathNewContext\n");
        xmlFreeDoc(doc);
        return 1;
    }

    xmlXPathObjectPtr result = xmlXPathEvalExpression((xmlChar *)"//a/@href", context);
    if (result == NULL || xmlXPathNodeSetIsEmpty(result->nodesetval)) {
        if (result != NULL) {
            xmlXPathFreeObject(result);
        }
        //fprintf(stderr, "No result from XPath\n");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return 1;
    }

    xmlNodeSetPtr nodeset = result->nodesetval;

    for (int i = 0; i < nodeset->nodeNr; ++i) {
        xmlChar *href = xmlNodeListGetString(doc, nodeset->nodeTab[i]->xmlChildrenNode, 1);
        if (href == NULL) {
            continue;
        }

        xmlChar *abs_url = xmlBuildURI(href, (xmlChar *)url);
        
        xmlFree(href);
        if (abs_url == NULL) {
            continue;
        }

        //printf("[HTML] Found link: %s\n", abs_url);

        if (strstr((char *)abs_url, "/image?q=")) {
            // Push to frontier like any other URL
            if (visited_check((char *)abs_url)) {
                frontier_push((char *)abs_url);
            }
            xmlFree(abs_url);
            continue;
        }

        char *abs_str = (char *)abs_url;

        if (!(strncmp(abs_str, "http://", 7) == 0 || strncmp(abs_str, "https://", 8) == 0)) {
            xmlFree(abs_url);
            continue;
        }

        if (visited_check((char *)abs_url)) {
            //printf("Found link: %s\n", abs_url);
            //printf("[HTML] New URL passed visited check: %s\n", abs_url);
            frontier_push((char *)abs_url);
            //printf("Pushed to frontier: %s\n", abs_url);
        } else {
            //printf("[HTML] Already visited (won't push): %s\n", abs_url);
        }

        xmlFree(abs_url);
    }

    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    return 0;
}

void *crawl_worker(void *arg){
    while (!done) { //keeps looping
        pthread_mutex_lock(&png_mutex);
        int enough_pngs = (png_count >= max_pngs);
        pthread_mutex_unlock(&png_mutex);

        if (enough_pngs || done) {
            //printf("[Main] Max PNGs reached. Done.\n");
            //done = 1;
            //frontier_wake_all();  // clean and encapsulated
            break;
        }

        //popping url from the frontier to do work
        char *url = frontier_pop();
        if (done) {      // check if we are terminating
            free(url);
            break;
        }
        if (url == NULL) {
            continue;
        }
        //printf("[Thread %ld] New URL marked visited: %s\n", pthread_self(), url);


        //download with curl and process, ALL FROM PAST LABS
        RECV_BUF recv_buf;
        recv_buf.buf = malloc(BUF_SIZE);
        recv_buf.size = 0; //this is the current size of valid data (starting at 0)
        recv_buf.max_size = BUF_SIZE; //max capacity
        recv_buf.seq = -1;    

        CURL *curl_handle = curl_easy_init();

        if (!curl_handle) {
            free(url);
            free(recv_buf.buf);
            curl_easy_cleanup(curl_handle);
            continue;
        }

        curl_easy_setopt(curl_handle, CURLOPT_URL, url);
        curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_cb_curl); 
        curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)&recv_buf);
        curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "ECE252-Crawler/1.0");
        curl_easy_setopt(curl_handle, CURLOPT_HEADERFUNCTION, header_cb_curl);
        curl_easy_setopt(curl_handle, CURLOPT_HEADERDATA, (void *)&recv_buf);
        curl_easy_setopt(curl_handle, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl_handle, CURLOPT_MAXREDIRS, 10L);

        CURLcode res = curl_easy_perform(curl_handle);

        char *effective_url = NULL;
        curl_easy_getinfo(curl_handle, CURLINFO_EFFECTIVE_URL, &effective_url);


        if (effective_url && strcmp(effective_url, url) != 0) {
            //printf("[Redirect] Switched to redirected URL: %s\n", effective_url);
            if (visited_check(effective_url)) {
                free(url);
                url = strdup(effective_url);  // overwrite the old URL so thread continues with it
            } else {
                //printf("[Thread] Redirected URL already visited: %s\n", effective_url);
                free(url);
                continue;  // already visited, skip
            }
        }


        if (res == CURLE_OK) { //if no errors
            //printf("[DEBUG] Received HTML");

            char *content = NULL;
            curl_easy_getinfo(curl_handle, CURLINFO_CONTENT_TYPE, &content); //store the content type into the pointer

            if (content && strstr(content, "text/html")) { //if it is html
                process_html(recv_buf.buf, recv_buf.size, url); //call process_html to extract the new links from the page and add to frontier
                //printf("[Thread %ld] Parsing HTML content from: %s\n", pthread_self(), url);
            } else if (recv_buf.size >= 8 && is_png((U8 *)recv_buf.buf, 8)) {
                int added = pnglist(url);
                if (added) {
                    char filename[32];
                    snprintf(filename, sizeof(filename), "image%d.png", png_count - 1);
                    FILE *fp = fopen(filename, "wb");
                    if (fp) {
                        fwrite(recv_buf.buf, 1, recv_buf.size, fp);
                        fclose(fp);
                    }
                }
            }
        }

        curl_easy_cleanup(curl_handle);

        free(recv_buf.buf);
        free(url);
    }
    return NULL;
}


void validate_png(const char *url) {
    if (png_count >= max_pngs) {
        return;
    }

    CURL *curl_handle = curl_easy_init();
    if (!curl_handle){
        return;
    }

    RECV_BUF recv_buf;
    recv_buf.buf = malloc(BUF_SIZE);
    recv_buf.size = 0;
    recv_buf.max_size = BUF_SIZE;
    recv_buf.seq = -1;

    curl_easy_setopt(curl_handle, CURLOPT_URL, url);
    curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_cb_curl);
    curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)&recv_buf);
    curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "ECE252-Crawler/1.0");
    curl_easy_setopt(curl_handle, CURLOPT_HEADERFUNCTION, header_cb_curl);
    curl_easy_setopt(curl_handle, CURLOPT_HEADERDATA, (void *)&recv_buf);
    curl_easy_setopt(curl_handle, CURLOPT_FOLLOWLOCATION, 1L);

    CURLcode res = curl_easy_perform(curl_handle);

    if (res == CURLE_OK && recv_buf.size >= 8 &&
    is_png((U8 *)recv_buf.buf, 8)) {

        int added = pnglist(url);  // pnglist() handles locking

        if (added) {
            char filename[32];
            snprintf(filename, sizeof(filename), "image%d.png", png_count - 1);  // already incremented in pnglist

            FILE *fp = fopen(filename, "wb");
            if (fp) {
                fwrite(recv_buf.buf, 1, recv_buf.size, fp);
                fclose(fp);
                //printf("[SAVE] Valid PNG downloaded and saved: %s\n", filename);
            }
        } else {
            //printf("[SKIP] PNG was valid but not added (duplicate or count exceeded): %s\n", url);
        }
    }

    curl_easy_cleanup(curl_handle);
    free(recv_buf.buf);
}


int main(int argc, char **argv) {
    int opt; //t, m, v

    while ((opt = getopt(argc, argv, "t:m:v:")) != -1) {
        switch (opt) {
            case 't': // -t is number of threads crawling the web
                num_threads = atoi(optarg); //atoi --> converting string to integer; ASCII to integer
                break;
            case 'm': // -m is number of unique png urls to find
                max_pngs = atoi(optarg);
                break;
            case 'v': // -v is loging all the visited urls by the crawler
                log_file = optarg;
                break;
            default:
                return 1;
        }
    }

    if (optind < argc) { //optind is a global variable from getopt() library, tells you the index of the next argument in argv[] that getopt didnt process
        seed_url = argv[optind];
    }

    if (seed_url == NULL) { //if the user did not provide seed_url
        return 1;
    }

    if (max_pngs >= 50) {
        max_pngs = 50;
    }

    struct timeval start_time, end_time;
    gettimeofday(&start_time, NULL); // Start timer

    //initializing all the lists we need 
    frontier_initialization();
    visited_initialization(); 

    frontier_push(seed_url); 
    visited_check(seed_url);  // mark it visited right away

    pthread_t threads[num_threads];

    //create threads
    for (int i=0; i<num_threads; i++) {
        pthread_create(&threads[i], NULL, crawl_worker, NULL);
    }

    // Wait for completion - simpler logic
    int idle_count = 0;
    while (!done) {
        pthread_mutex_lock(&png_mutex);
        int current_png_count = png_count;
        pthread_mutex_unlock(&png_mutex);
        
        // Check if we have enough PNGs
        if (current_png_count >= max_pngs) {
            //printf("[Main] Found %d PNGs, stopping.\n", current_png_count);
            done = 1;
            frontier_wake_all();
            break;
        }
        
        // Check if frontier is empty - if so, wait a bit longer before giving up
        if (frontier_empty()) {
            idle_count++;
            if (idle_count > 50) {  // Wait 5 seconds (50 * 100ms) before giving up
                //printf("[Main] No more URLs to process, stopping.\n");
                done = 1;
                frontier_wake_all();
                break;
            }
        } else {
            idle_count = 0;  // Reset counter if frontier has work
        }
        
        usleep(100000); // Sleep for 100ms
    }

    //wait for each thread to finish
    for (int i=0; i<num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    /* NO NEED, just need to log it
    //download_pngs(); 

    //concatenate into all.png
    char *args[MAX_PNGS];
    char filenames[MAX_PNGS][32];

    for (int i = 0; i < png_count; i++) {
        snprintf(filenames[i], sizeof(filenames[i]), "image%d.png", i);
        args[i] = filenames[i];
    }

    concatenate_png(png_count, args);
    */

    if (log_file != NULL) {
        FILE *fp = fopen(log_file, "w");
        if (fp != NULL) {
            visited_log(fp);
            fclose(fp);
        } else {
            perror("fopen (log_file)");
        }
    }

    // Save found PNG URLs to png_urls.txt
    FILE *png_fp = fopen("png_urls.txt", "w");
    if (png_fp != NULL) {
        for (int i = 0; i < png_count; i++) {
            fprintf(png_fp, "%s\n", png_urls[i]);
        }
        fclose(png_fp);
    } else {
        perror("fopen (png_urls.txt)");
    }


    gettimeofday(&end_time, NULL);  // Stop timer

    double elapsed = (end_time.tv_sec - start_time.tv_sec) +
                     (end_time.tv_usec - start_time.tv_usec) / 1000000.0;

    printf("findpng2 execution time: %.6f seconds\n", elapsed);

    //destroying the lists we used
    frontier_destroy();
    visited_destroy();

    return 0;
}
#ifndef VISITED_H
#define VISITED_H

void visited_initialization(); //setup mutex and hashtable
int visited_check(const char *url); //checking if there are duplicates, if no duplicates, add to the list
void visited_destroy(); //clean up
void visited_log(FILE *fp);

#endif
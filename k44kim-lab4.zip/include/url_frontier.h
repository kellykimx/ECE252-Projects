#ifndef URL_FRONTIER_H
#define URL_FRONTIER_H


void frontier_initialization(); //this will initialize everything for the list
void frontier_destroy(); //this will clean up the list
void frontier_push(const char *url); //adding a new url into the list
char *frontier_pop(); //removes and moves onto the next thing on the list
int frontier_empty(); //checking if the list is empty
void frontier_wake_all(void);
#endif
#!/bin/bash

OUTFILE="lab5_eceubuntu1.csv"
NUM_RUNS=5
SEED_URL="http://ece252-1.uwaterloo.ca/lab4"
LOG_FILE="png_urls.txt"
EXECUTABLE="./findpng3"

echo "T,M,Time" > "$OUTFILE"

# Array of (T M) test cases from your image
test_cases=(
"1 1"
"1 10"
"1 20"
"1 30"
"1 40"
"1 50"
"1 100"
"10 1"
"10 10"
"10 20"
"10 30"
"10 40"
"10 50"
"10 100"
"20 1"
"20 10"
"20 20"
"20 30"
"20 40"
"20 50"
"20 100"
)

for cfg in "${test_cases[@]}"; do
    T=$(echo "$cfg" | awk '{print $1}')
    M=$(echo "$cfg" | awk '{print $2}')
    
    total_time=0

    for ((i = 1; i <= NUM_RUNS; i++)); do
        make clean > /dev/null
        make > /dev/null

        output=$($EXECUTABLE -t "$T" -m "$M" -v "$LOG_FILE" "$SEED_URL" | grep "findpng3 execution time:")
        time=$(echo "$output" | awk '{print $4}')

        if [[ -n "$time" ]]; then
            total_time=$(echo "$total_time + $time" | bc)
            echo "Run $i: T=$T M=$M -> time=$time"
        else
            echo "Run $i: T=$T M=$M -> time=ERROR"
        fi
    done

    avg=$(echo "scale=6; $total_time / $NUM_RUNS" | bc)
    echo "$T,$M,$avg" >> "$OUTFILE"
done

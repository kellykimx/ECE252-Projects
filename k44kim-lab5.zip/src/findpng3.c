//most code are from lab4
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <curl/curl.h>
#include <curl/multi.h>
#include <libxml/HTMLparser.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/uri.h>
#include <getopt.h>
#include <sys/time.h>
#include "url_frontier.h"
#include "visited.h"
#include "lab_png.h" 

#define MAX_PNGS 50
#define BUF_SIZE 1048576  //1MB inital buffer
#define ECE252_HEADER "X-Ece252-Fragment: "
#define SEED_URL "http://ece252-1.uwaterloo.ca/lab4/"
#define MAX_WAIT_MSECS 30*1000

int concurrent_connections = 1; //default number of concurrent connections
int max_pngs = MAX_PNGS; //max number of pngs to collect
int png_count = 0; //tracking how many pngs we have found
char *log_file = NULL; //visited url list
char *seed_url = NULL; //starting point
char *png_urls[MAX_PNGS]; //storing the png urls

typedef struct recv_buf {
    char *buf;       /* memory to hold a copy of received data */
    size_t size;     /* size of valid data in buf in bytes*/
    size_t max_size; /* max capacity of buf in bytes*/
    char *url;       /* will be used for logging, etc.*/
} RECV_BUF;

//since this lab is using curl multi to allow multiple parallel transfers
typedef struct conc_connections{
    CURL *eh; //will be handling individual transfer 
    RECV_BUF buffer; //holds the download data for specific url
    int active; //tracking whether the data has been fetched or not
} CONC_CONNECTIONS;


//from past labs
size_t write_cb_curl(char *p_recv, size_t size, size_t nmemb, void *p_userdata) {
    size_t realsize = size * nmemb; //calculating the total number of bytes received in this callback
    RECV_BUF *p = (RECV_BUF *)p_userdata;
 
    //checking if there is enough space left in the buffer to store new data
    if (p->size + realsize > p->max_size) {
        return 0;
    }

    memcpy(p->buf + p->size, p_recv, realsize); /*copy data from libcurl*/
    p->size += realsize; //update the total number of valid bytes in buffer

    return realsize;
}

//referencing from the starter code
int process_html(const char *buf, int size, const char *url) {

    //printf("[DEBUG] Entered process_html()\n");


    int opts = HTML_PARSE_NOBLANKS | HTML_PARSE_NOERROR | \
               HTML_PARSE_NOWARNING | HTML_PARSE_NONET;
    htmlDocPtr doc = htmlReadMemory(buf, size, url, NULL, opts);

    if ( doc == NULL ) {
        //fprintf(stderr, "Document not parsed successfully.\n");
        return 1;
    }

    xmlXPathContextPtr context = xmlXPathNewContext(doc);
    if (context == NULL) {
        //printf("Error in xmlXPathNewContext\n");
        xmlFreeDoc(doc);
        return 1;
    }

    xmlXPathObjectPtr result = xmlXPathEvalExpression((xmlChar *)"//a/@href", context);
    if (result == NULL || xmlXPathNodeSetIsEmpty(result->nodesetval)) {
        if (result != NULL) {
            xmlXPathFreeObject(result);
        }
        //fprintf(stderr, "No result from XPath\n");
        xmlXPathFreeContext(context);
        xmlFreeDoc(doc);
        return 1;
    }

    xmlNodeSetPtr nodeset = result->nodesetval;

    for (int i = 0; i < nodeset->nodeNr; ++i) {
        xmlChar *href = xmlNodeListGetString(doc, nodeset->nodeTab[i]->xmlChildrenNode, 1);
        if (href == NULL) {
            continue;
        }

        xmlChar *abs_url = xmlBuildURI(href, (xmlChar *)url);
        
        xmlFree(href);
        if (abs_url == NULL) {
            continue;
        }

        //printf("[HTML] Found link: %s\n", abs_url);

        if (strstr((char *)abs_url, "/image?q=")) {
            //printf("[DEBUG] Found PNG-like link: %s\n", abs_url);
            // Push to frontier like any other URL
            if (visited_check((char *)abs_url)) {
                frontier_push((char *)abs_url);
                //printf("[DEBUG] Pushed to frontier: %s\n", abs_url);
            }
            xmlFree(abs_url);
            continue;
        }

        char *abs_str = (char *)abs_url;

        if (!(strncmp(abs_str, "http://", 7) == 0 || strncmp(abs_str, "https://", 8) == 0)) {
            xmlFree(abs_url);
            continue;
        }

        if (visited_check((char *)abs_url)) {
            //printf("Found link: %s\n", abs_url);
            //printf("[HTML] New URL passed visited check: %s\n", abs_url);
            frontier_push((char *)abs_url);
            //printf("Pushed to frontier: %s\n", abs_url);
        } else {
            //printf("[HTML] Already visited (won't push): %s\n", abs_url);
        }

        xmlFree(abs_url);
    }

    xmlXPathFreeObject(result);
    xmlXPathFreeContext(context);
    xmlFreeDoc(doc);

    return 0;
}

//this function is to prepare the slot to download url, png --> setting them as active 
int fetch(CURLM *cm, CONC_CONNECTIONS *slot, const char *url) {
    if (url==NULL) {
        return 1;
    }

    if (slot->buffer.buf == NULL) {
        slot->buffer.buf = malloc(BUF_SIZE);
        if (slot->buffer.buf == NULL) {
            return 1;
        }
        slot->buffer.max_size = BUF_SIZE;
    }

    memset(slot->buffer.buf, 0, slot->buffer.max_size);
    slot->buffer.size = 0;

    if (slot->buffer.url != NULL) {
        free(slot->buffer.url);
    }

    slot->buffer.url=strdup(url); //save the url to the slot

    curl_easy_setopt(slot->eh, CURLOPT_URL, url);
    curl_easy_setopt(slot->eh, CURLOPT_WRITEFUNCTION, write_cb_curl);
    curl_easy_setopt(slot->eh, CURLOPT_WRITEDATA, &slot->buffer);
    curl_easy_setopt(slot->eh, CURLOPT_PRIVATE, slot);
    curl_easy_setopt(slot->eh, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(slot->eh, CURLOPT_NOBODY, 0L);                  // download body
    curl_easy_setopt(slot->eh, CURLOPT_HEADER, 0L);                  // do not include headers in body
    curl_easy_setopt(slot->eh, CURLOPT_ACCEPT_ENCODING, "");         // enable compressed content
    curl_easy_setopt(slot->eh, CURLOPT_USERAGENT, "libcurl-agent/1.0"); // required for some servers

    //printf("[DEBUG] Fetching URL: %s\n", url);

    CURLMcode rc = curl_multi_add_handle(cm, slot->eh);

    if (rc != CURLM_OK) {
        return 1;
    }

    slot->active=1; //set the slot as active
    return 0;
}

//this function manages multiple concurrent downloads --> collecting png images and discovering links
void crawl_multi (CURLM *cm, CONC_CONNECTIONS *slots) {
    int still_running = 0;
    int msgs_left=0;

    while ( (png_count < max_pngs && !frontier_empty()) || still_running != 0) { //if there are more png images to get + frontier is not empty OR if there are active transfers happening
        //fill in slots that are left (not active)
        //printf("[DEBUG] Loop: png_count = %d, frontier_empty = %d, still_running = %d\n", png_count, frontier_empty(), still_running);

         if (png_count >= max_pngs) {
            break;  // Exit early if we've found enough PNGs
        }

        for (int i=0; i<concurrent_connections; i++) {
            if (!slots[i].active ) {
                char *next_url = frontier_pop();

                //printf("[DEBUG] frontier_pop() returned: %s\n", next_url ? next_url : "NULL");
                
                if (next_url == NULL) { //if there are no more urls left in the queue
                    //printf("[DEBUG] No more URLs in frontier\n");
                    continue;
                }

                //printf("[DEBUG] Checking if URL was visited: %s\n", next_url);
                int not_visited = visited_check(next_url);
                //printf("[DEBUG] visited_check() returned: %d (1=not visited, 0=visited)\n", not_visited);

                if (!not_visited) {
                    //printf("[DEBUG] URL already visited, discarding: %s\n", next_url);
                    free(next_url); // already visited, discard
                    continue;
                }
                visited_add(next_url);
                //printf("[DEBUG] Marked as visited and starting fetch for: %s\n", next_url);
                
                fetch(cm, &slots[i], next_url);
                free(next_url);
            }
        }


        CURLMcode mcode = curl_multi_perform(cm, &still_running);
 
        //if transfers are active, wait for network activity
        if (still_running) {
            mcode = curl_multi_wait(cm, NULL, 0, MAX_WAIT_MSECS, NULL);
            if (mcode != CURLM_OK) {
                //fprintf(stderr, "curl_multi_wait() failed, code %d.\n", mcode);
                return;
            }
        }
        curl_multi_perform(cm, &still_running);


        // CURLMcode mcode = curl_multi_perform(cm, &still_running);
        // if (mcode != CURLM_OK) {
        //     fprintf(stderr, "curl_multi_perform error: %s\n", curl_multi_strerror(mcode));
        // }

        //curl_multi_wait(cm, NULL, 0, MAX_WAIT_MSECS, NULL);

        CURLMsg *msg;

        //references from curl_multi_test.c
        while ((msg=curl_multi_info_read(cm, &msgs_left))) {
            if (msg->msg == CURLMSG_DONE) {

                CURL *easy = msg->easy_handle;
                CONC_CONNECTIONS *slot = NULL;
                curl_easy_getinfo(easy, CURLINFO_PRIVATE, (void **)&slot);

                char *content_type = NULL;
                curl_easy_getinfo(easy, CURLINFO_CONTENT_TYPE, &content_type);

                long response_code = 0;
                curl_easy_getinfo(easy, CURLINFO_RESPONSE_CODE, &response_code);
                //printf("[DEBUG] HTTP Response Code: %ld\n", response_code);


                //printf("[DEBUG] Content-Type: %s\n", content_type);

                int is_valid_png = 0;

                if (slot->buffer.size >= 8) {
                    // printf("[DEBUG] First 8 bytes: %02x %02x %02x %02x %02x %02x %02x %02x\n",
                    //     (unsigned char)slot->buffer.buf[0], (unsigned char)slot->buffer.buf[1],
                    //     (unsigned char)slot->buffer.buf[2], (unsigned char)slot->buffer.buf[3],
                    //     (unsigned char)slot->buffer.buf[4], (unsigned char)slot->buffer.buf[5],
                    //     (unsigned char)slot->buffer.buf[6], (unsigned char)slot->buffer.buf[7]);

                    is_valid_png = is_png((U8 *)slot->buffer.buf, slot->buffer.size);
                    //printf("[DEBUG] is_png() function returned: %d\n", is_valid_png);

                }
                
                if (is_valid_png==1) {
                    if (png_count < max_pngs) {
                        //printf("[DEBUG] Valid PNG confirmed: %s\n", slot->buffer.url);
                        png_urls[png_count] = strdup(slot->buffer.url);
                        png_count++;
                    } else {
                        //printf("[DEBUG] Valid PNG found but max limit reached: %s\n", slot->buffer.url);
                    }
                } else if (content_type != NULL && strstr(content_type, "text/html") != NULL) {
                    //printf("[DEBUG] Detected HTML content. Processing links...\n");
                    process_html(slot->buffer.buf, slot->buffer.size, slot->buffer.url);
                } else {
                    //printf("[DEBUG] Unknown content type or invalid PNG. Skipping.\n");
                }

                // Clean up
                curl_multi_remove_handle(cm, easy);
                curl_easy_reset(slot->eh);  // Reset instead of cleanup + new init
                slot->active = 0;
                if (slot->buffer.url != NULL) {
                    free(slot->buffer.url);
                    slot->buffer.url = NULL;
                }
                slot->buffer.size = 0;
            }
        }
    }
}


int main(int argc, char **argv) {
    int opt; //t, m, v

    while ((opt = getopt(argc, argv, "t:m:v:")) != -1) {
        switch (opt) {
            case 't': // -t is number of threads crawling the web
                concurrent_connections = atoi(optarg); //atoi --> converting string to integer; ASCII to integer
                break;
            case 'm': // -m is number of unique png urls to find
                max_pngs = atoi(optarg);
                break;
            case 'v': // -v is loging all the visited urls by the crawler
                log_file = optarg;
                break;
            default:
                return 1;
        }
    }

    if (optind < argc) { //optind is a global variable from getopt() library, tells you the index of the next argument in argv[] that getopt didnt process
        seed_url = argv[optind];
    }

    if (seed_url == NULL) { //if the user did not provide seed_url
        return 1;
    }

    if (concurrent_connections <= 0) {
        concurrent_connections = 1;
    }

    if (max_pngs > MAX_PNGS) {
        max_pngs = MAX_PNGS;
    }

    memset(png_urls, 0, sizeof(png_urls));

    struct timeval start_time, end_time;
    gettimeofday(&start_time, NULL); // Start timer

    curl_global_init(CURL_GLOBAL_ALL);
    CURLM *cm = curl_multi_init();

    CONC_CONNECTIONS slots[concurrent_connections]; //array of concurrent connections

    //initializing each of the connection slots that will be used
    for (int i=0; i<concurrent_connections; i++) {
        slots[i].eh = curl_easy_init();
        slots[i].buffer.buf = malloc(BUF_SIZE);
        slots[i].buffer.size = 0;
        slots[i].buffer.max_size = BUF_SIZE;
        slots[i].buffer.url = NULL;
        slots[i].active = 0;
    }

    frontier_initialization();
    visited_initialization();

    frontier_push(seed_url);
    //printf("[DEBUG] Pushed seed URL: %s\n", seed_url);


    crawl_multi(cm, slots);


    if (log_file != NULL) {
        FILE *fp = fopen(log_file, "w");
        if (fp != NULL) {
            visited_log(fp);
            fclose(fp);
        } else {
            perror("fopen (log_file)");
        }
    }

    // Save found PNG URLs to png_urls.txt
    FILE *png_fp = fopen("png_urls.txt", "w");
    if (png_fp != NULL) {
        for (int i = 0; i < png_count; i++) {
            fprintf(png_fp, "%s\n", png_urls[i]);
        }
        fclose(png_fp);
    } else {
        perror("fopen (png_urls.txt)");
    }

    //free allocated memory
    for (int i = 0; i < concurrent_connections; i++) {
        if (slots[i].active) {
            curl_multi_remove_handle(cm, slots[i].eh);
        }
        curl_easy_cleanup(slots[i].eh);
        free(slots[i].buffer.buf);
        if (slots[i].buffer.url != NULL) {
            free(slots[i].buffer.url);
        }
    }

    //free PNG urls
    for (int i = 0; i < png_count; i++) {
        if (png_urls[i] != NULL) {
            free(png_urls[i]);
        }
    }

    frontier_destroy();
    visited_destroy();

    curl_multi_cleanup(cm);
    curl_global_cleanup();


    gettimeofday(&end_time, NULL);  // Stop timer

    double elapsed = (end_time.tv_sec - start_time.tv_sec) +
                     (end_time.tv_usec - start_time.tv_usec) / 1000000.0;

    printf("findpng3 execution time: %.6f seconds\n", elapsed);
    //printf("[INFO] PNGs found: %d\n", png_count);

    return 0;
}
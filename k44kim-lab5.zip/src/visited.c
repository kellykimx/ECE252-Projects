#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "visited.h"

#define hash_slots 1024 //number of slots in hash table

static char *visited_ordered[1000];
static int visited_ordered_count = 0;

typedef struct visited_node {
    char *url;
    struct visited_node *next;
} visited_node_t;

static visited_node_t *slots[hash_slots];

static unsigned long hash_table(const char *url) {
    unsigned long hash = 5381;

    int c; //for each character

    while ((c=*url++)) { //loop stops when it reaches the terminator character \0
        hash = ((hash<<5)+hash)+c; 
    }
    return hash % hash_slots;
    //keeps running for each characyer in the input string, into the hash
}

void visited_initialization() {
    for (int i = 0; i < hash_slots; i++) {
        slots[i]=NULL; //making sure that the table is empty at the start
    }
    visited_ordered_count=0;
}

int visited_check(const char *url) {
    unsigned long index = hash_table(url); //check where the url should have been stored
    visited_node_t *checking = slots[index];

    while (checking != NULL) {
        if (strcmp(checking->url, url)==0) { //if the url already exsits
            return 0;
        }
        checking = checking->next; //now moving onto the next url to check
    }
    return 1;
}

int visited_add(const char *url) {
    // First check if it's already there to avoid duplicates
    if (!visited_check(url)) {
        return 1; // Already visited
    }
    
    unsigned long index = hash_table(url);
    
    visited_node_t *new = malloc(sizeof(visited_node_t));
    new->url = strdup(url);
    new->next = slots[index];
    slots[index] = new; //inserting at the front of the list for slots[index]
    
    if (visited_ordered_count < 1000) {
        visited_ordered[visited_ordered_count++] = new->url;
    }
}


void visited_destroy() {
    
    for (int i=0; i<hash_slots; i++) { //loop through every slots in hash table
        visited_node_t *current = slots[i];
        while (current != NULL) {
            visited_node_t *next = current->next;
            free(current->url); //free the memory
            free(current); //free the node itself
            current = next;
        }
        slots[i]=NULL;
    }

    visited_ordered_count = 0;
}

void visited_log(FILE *fp) {
    for (int i = 0; i < visited_ordered_count; i++) {
        fprintf(fp, "%s\n", visited_ordered[i]);
    }
}
